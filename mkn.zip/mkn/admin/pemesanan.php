<?php
// Database connection
$servername = "localhost";
$username = "root"; // Use your database username
$password = ""; // Use your database password
$dbname = "makanan"; // Replace with your database name

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Fetch orders from the database
$sql = "SELECT * FROM orders";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <link rel="icon" type="image/png" href="assets/img/favicon.png">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>MKN Admin</title>
  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no'
    name='viewport' />
  <!-- Fonts and icons -->
  <link rel="stylesheet" type="text/css"
    href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
  <!-- CSS Files -->
  <link href="assets/css/material-dashboard.css?v=2.1.1" rel="stylesheet" />
  <link href="assets/demo/demo.css" rel="stylesheet" />
</head>

<body>
  <!-- Wrapper -->
  <div class="wrapper ">

    <!-- Sidebar -->
    <div class="sidebar" data-color="danger" data-background-color="white" data-image="assets/img/sidebar-3.jpg">
      <div class="logo">
        <a href="#" class="simple-text logo-normal">
          MKN
        </a>
      </div>
      <div class="sidebar-wrapper">
        <ul class="nav">
          <li class="nav-item">
            <a class="nav-link" href="./dashboard.php">
              <i class="material-icons">dashboard</i><br>
            </a>
          </li>
          <li class="nav-item active">
            <a class="nav-link" href="./users.php">
              <i class="material-icons">Pemesanan</i><br>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="./data_produk.php">
              <i class="material-icons">Produk</i><br>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="./users.php">
              <i class="material-icons">user</i></a>
          </li>
        </ul>
      </div>
    </div>
    <!-- End Sidebar -->

    <!-- Main -->
    <div class="main-panel">
      <!-- Navbar -->
      <nav class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top ">
        <div class="container-fluid">
          <div class="navbar-wrapper">
            <a class="navbar-brand" href="#">Data pemesanan</a>
          </div>
          <!-- Hamburger Menu -->
          <button class="navbar-toggler" type="button" data-toggle="collapse" aria-controls="navigation-index"
            aria-expanded="false" aria-label="Toggle navigation">
            <span class="sr-only">Toggle navigation</span>
            <span class="navbar-toggler-icon icon-bar"></span>
            <span class="navbar-toggler-icon icon-bar"></span>
            <span class="navbar-toggler-icon icon-bar"></span>
          </button>
          <!-- End Hamburger Menu -->
          <!-- Include Logout -->
          <?php
          include 'colapse-person.php';
          ?>
          <!-- End Include Logout -->
        </div>
      </nav>
      <!-- End Navbar -->

      <!-- Data Table -->
      <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-danger">
                  <h3 class="card-title ">Data Pemesanan</h3>
                </div>
                <div class="card-body">
                  <div class="table-responsive">
                    <table class="table table-hover">
                      <thead>
                        <tr>
                          <th>ID</th>
                          <th>Name order</th>
                          <th>Email</th>
                          <th>Address</th>
                          <th>City</th>
                          <th>Postal Code</th>
                          <th>Phone</th>
                          <th>Notes</th>
                          <th>Product</th>
                          <th>Quantity</th>
                          <th>Total Price</th>
                          <th>Shipping Cost</th>
                          <th>Total Order</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php
                        if ($result->num_rows > 0) {
                          // Output data of each row
                          while ($row = $result->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . htmlspecialchars($row["id"]) . "</td>";
                            echo "<td>" . htmlspecialchars($row["first_name"]) . "</td>";
                            echo "<td>" . htmlspecialchars($row["email"]) . "</td>";
                            echo "<td>" . htmlspecialchars($row["address"]) . "</td>";
                            echo "<td>" . htmlspecialchars($row["city"]) . "</td>";
                            echo "<td>" . htmlspecialchars($row["postal_code"]) . "</td>";
                            echo "<td>" . htmlspecialchars($row["phone"]) . "</td>";
                            echo "<td>" . htmlspecialchars($row["notes"]) . "</td>";
                            echo "<td>" . htmlspecialchars($row["nama_produk"]) . "</td>";
                            echo "<td>" . htmlspecialchars($row["product_quantity"]) . "</td>";
                            echo "<td>" . htmlspecialchars($row["total_price"]) . "</td>";
                            echo "<td>" . htmlspecialchars($row["shipping_cost"]) . "</td>";
                            echo "<td>" . htmlspecialchars($row["total_order"]) . "</td>";
                            echo "<td>
                              <form action='admin.php' method='post' style='display:inline;'>
                                <input type='hidden' name='delete' value='" . htmlspecialchars($row['id']) . "'>
                                <button type='submit' class='btn btn-danger btn-sm' onclick='return confirm(\"Are you sure you want to delete this order?\");'>Delete</button>
                              </form>
                            </td>";
                            echo "</tr>";
                          }
                        } else {
                          echo "<tr><td colspan='14'>No orders found</td></tr>";
                        }
                        $conn->close();
                        ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- End Data Table -->

      <!-- Footer -->
      <footer class="footer">
        <div class="container-fluid">
          <div class="copyright float-right">
            &copy;
            <script>
              document.write(new Date().getFullYear())
            </script>, made with <i class="material-icons">favorite</i> by
            <a href="#" class="text-danger">MKN Team</a> for you.
          </div>
        </div>
      </footer>
      <!-- End Footer -->

    </div>
    <!-- End Main -->

  </div>
  <!-- End Wrapper -->

  <!-- Core JS Files -->
  <script src="assets/js/core/jquery.min.js"></script>
  <script src="assets/js/core/popper.min.js"></script>
  <script src="assets/js/core/bootstrap-material-design.min.js"></script>
  <script src="assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
  <!-- Plugin for the momentJs -->
  <script src="assets/js/plugins/moment.min.js"></script>
  <!-- Plugin for Sweet Alert -->
  <script src="assets/js/plugins/sweetalert2.js"></script>
  <!-- Forms
